
# photogeoref example 1

Georeferencing An annotated photgraph of Peak Montihuero in the Cantabrian Mountains to a 5 m resolution DEM
The photograph has highlighted in blue the catchment of a rock glacier on its eastern side. Some morraine-like ridges are also marked.
The photograph was taken with a Sony DSC-RX100 with Zeiss lense at 9mm focal length

## Process

Edit the settings file and change the path to the actual path where you unzipped example-1.zip

Run the script:

`python3 photogeoref.py`

It will load the default settings file "georefsettings.yml"

Click on Load settings and check that all field are populated

Then click on "Process GCP". Change the values as much as you like and click "Process GCP" until you are satisfied with the results.

Click on Accept and chack the new files created in the directory where the photograph is stored.


Full documentation at: https://www.meteoexploration.com/python/photogeoref/index.html

